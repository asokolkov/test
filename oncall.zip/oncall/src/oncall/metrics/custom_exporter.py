from prometheus_client import start_http_server, Summary
import logging
import re


logger = logging.getLogger()


MESSAGE_SEND_TIME = Summary('message_send_time_seconds', 'Time spent sending message.')
MESSAGES_SENT = Summary('sent_messages_total', 'Average amount of sent messages.')

class CustomExporter:
    def __init__(self, config, appname):
        try:
            port = int(config['custom-exporter'][appname]['server_port'])
        except (ValueError, KeyError):
            logger.warning('custom-exporter server_port not present in config. running without custom metrics.')
            self.enable_metrics = False
            return

        self.gauges = {}

        # per docs, app name in metric prefix needs to be one word
        self.appname = re.sub('[^a-zA-Z0-9]+', '', appname)

        logger.warning('Starting custom-exporter metrics web server at %s', port)
        start_http_server(port)
        self.enable_metrics = True