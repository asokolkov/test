#!/bin/bash

make serve &
make check
